export class Car {
  id: number;
  make: string;
  model: string;
  color: string;
  year: number;
  price: number;
}