import { Component } from "@angular/core";

// import the HTML file and stylesheet with paths relative to this file

@Component({
  selector: "app-menu",
  templateUrl: './menu.component.html',
  styleUrls: [ './menu.component.css' ],
})
export class AppMenuComponent {
  
}